from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add_item/', views.add_item, name='add_item'),
    path('view_items', views.view_items, name='view_items'),
    path('edit_item/<int:id>/',views.edit, name='edit')
]