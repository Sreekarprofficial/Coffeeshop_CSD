from django.db import models


class Item(models.Model):
    item_name = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    size = models.CharField(max_length=50)
    price = models.CharField(max_length=50)

    def __str__(self):
        return self.item_name

