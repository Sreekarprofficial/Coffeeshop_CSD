from django.shortcuts import render,redirect
from .models import Item

def home(request):
    return render(request, 'home.html')

def add_item(request):
    if request.method == 'POST':
        # Handle form submission and save the item
        item_name = request.POST.get('item_name')
        category = request.POST.get('category')
        size = request.POST.get('size')
        price = request.POST.get('price')

        # for creating and saving the new item
        Item.objects.create(item_name=item_name, category=category, size=size, price=price)

        # Redirect to the view_items page after saving
        return redirect('view_items')
    return render(request, 'add_item.html')

def view_items(request):
    items = Item.objects.all()
    return render(request, 'view_items.html', {'items': items})

def edit(request, id):
    item = Item.objects.get(id=id)
    if request.method == 'POST':
        # Handle form submission and update the item
        item.item_name = request.POST.get('item_name')
        item.category = request.POST.get('category')
        item.size = request.POST.get('size')
        item.price = request.POST.get('price')
        item.save()

        # Redirect to the view_items page after saving
        return redirect('view_items', id=item.id)